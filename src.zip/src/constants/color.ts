export const TEXTS = "text-[#1f1f1f]";
