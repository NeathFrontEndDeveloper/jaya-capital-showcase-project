// import HeroSection from "./content/heroSection";
import ComingSoon from "@/components/client/shared/comingsoon";

export default function Page() {
  return (
    <div className="w-full min-h-screen">
      <ComingSoon />
      {/* <HeroSection />
      <h1>This is testimonials page for client</h1> */}
    </div>
  );
}
