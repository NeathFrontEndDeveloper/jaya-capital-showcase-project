import Testimonials from "./content/testimonials";
// import ComingSoon from "@/components/shared/comingsoon";

export default function Page() {
  return (
    <div className="w-full min-h-screen">
      {/* <ComingSoon /> */}
      <Testimonials />
      {/* <h1>This is testimonials page for client</h1> */}
    </div>
  );
}
