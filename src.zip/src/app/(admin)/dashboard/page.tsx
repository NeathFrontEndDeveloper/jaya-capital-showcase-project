"use client";

const Dashboard = () => {
  return (
    <div>
      <h1>This is Dashboard</h1>
    </div>
  );
};

export default Dashboard;
